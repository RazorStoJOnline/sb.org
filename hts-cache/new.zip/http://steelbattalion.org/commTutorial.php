<html><head><title>Steel Battalion :: Org  \\ Comm. Tutorial</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420><img src='headerCommTutorial.gif' height=34 width=348 alt='Recon___________'><br><span class=body>Line of Contact Warfare Section ::</span><br><a href=warfare.php><span class=link>Back to Warfare Main</span></a><P>
<P>
<span class=header>Cause it's confusing :: Campaign Mode Communication</span><P>
<span class=body>On the controller, there are 2 buttons and a Tuner Dial that are required for communication.  The first button is to activate a communication connection. The 2nd button is to end one.  The Tuner Dial is used to select which channel you want.</span><P>
<img src=commTutorialMedia/controllerButtons.jpg><P>
<span class=body>When you're in the lobby, each person has a number in the lobby.  The person on the top of the list is number 1, and the person below them is number 2, and so forth.  This is important for communications, because this number is also their channel number on the tuner.</span><P>
<span class=body>Once the match starts you can turn the Tuner Dial on the controller and see that on the HUD (heads up display) the Tuner moves depending on how you move the dial.  One click of the dial to the right and the Tuner moves one position right (though I've seen the game act funny and reverse this, so don't be surprised if sometimes it's inverted).</span><P>
<img src=commTutorialMedia/tuner.jpg><P>
<span class=body>You'll notice on the tuner above each "notch" there is a number.  They're barely readable, but yes they are numbers, from 1 - 5.  Each number has a corresponding teammate (if you have 5 people on your team).  If you want to speak to the person on channel 2, turn the Dial until the "cursor" is at "notch" 2, and hit the connect button.  At this point, 1 of 2 things will happen.  If the person is not engaged in a conversation with someone else, they will instantly be connected to you; and you'll see their avatar and name appear in the bottom submonitor:</span><P>
<img src=commTutorialMedia/channelTwo.jpg><P>
<span class=body>However, if this person is already talking to someone else, the active channel light will blink dimly, and that person will get a bright orange blinky light on your channel and an annoying noise indicating that you want to talk to them.  When you're on the receiving end of this, it looks like this:</span><P>
<img src=commTutorialMedia/blinkyOrange.jpg><P>
<span class=body>At which point you can either ignore them, and let the noise drive you to ejecting prematurely, or scroll over to their channel (in this case 3) and say "how can I help you sir?" or whatever happens to be on your mind.</span><P>
<span class=body>If you're in the middle of a conversation and you just don't want to talk to them anymore, and you don't want to talk to anyone else either, you can just hit the 2nd communicator button, or the "disconnect" button as labeled on the first image up there.  This will make their avatar disappear from your bottom submonitor and you'll be in peaceful solitude.  If you want to open the channel again, just hit the "connect" button (1st Comm. button).</span><P>
<span class=body>That's about it for the functionality of the communicator.  Now all that's left is:</span><P>
<span class=header>How the hell do I tell who's on which channel?</span><img src=greyPixel.gif width=100% height=1><P>
<span class=body>There are a couple ways to do this, and they're all fairly straightforward.<P>
<span class=body>1: Memorize everybody's placement on the list from the lobby.<br>
2: Look at their arrows on the Map<br>
3: Look at the big freakin' box around their VT on the main screen.</span><P>
<span class=body>The 1st one needs no explanation, but for the 2nd two I've created handy dandy images so you can tell wtf I'm talking about.</span><P>
<img src=commTutorialMedia/teammatesMain.jpg><P>
<span class=body>As you can see, below the big green box around friendly VTs on the screen (which show up through hills and other objects, regardless of distance) there is a tiny number.  This is their Comm. number.  You'll also notice that if you're communicating with one (in this case Pilot 3) their big green box will pulse (as shown in this screenshot).</span><P>
<img src=commTutorialMedia/teammatesMap.jpg><P>
<span class=body>On the map it's the same deal.  Your friendly VTs show up as big arrows, with little white numbers next to them.  The numbers are their Comm. channels.  This is the easiest way to see what channel YOU are on.  In this case, you're channel 1.</span><P>
<span class=body>You'll also notice that these numbers are freakin' tiny and impossible to read.  That's where the F2 and F3 buttons come in; use them to zoom in on the submonitors.  Now you're communicating like a pro.  Rock!</span><P>
<span class=header>Dead, Dropped, Exploding, or Never There in the First Place</span><img src=greyPixel.gif width=100% height=1><P>
<span class=body>If you scroll to a channel and hit the connect button, and it makes a sad little "blip" noise and nothing happens, that indicates that there's nobody on that channel.  If there USED to be someone on that channel, it means they're dead or gone; and they're not in the match anymore -- they're not coming back.  If they were starting up or in the spawn point selection screen, you'd connect to them and you'd hear them complaining.
<P>
<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>