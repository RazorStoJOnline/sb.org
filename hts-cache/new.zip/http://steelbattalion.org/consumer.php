<html><head><title>Steel Battalion :: Org  \\ Media</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420><img src='headerRecon.gif' height=34 width=348 alt='Recon___________'>
<P>
<span class=header>Amazing Cabinets and Environments ideal for Steel Battalion</span><br>
<a href=recon.php><span class=link>back to media</span></a>
<P>
<span class=header>6 - The Command Station</span><span class=date> :: 02.06.05</span><br><span class=body>A brilliantly designed, super affordable stand built by member of the community tualagoodknight, specifically for Steel Battalion.  More pics and ordering info at: <a href=http://www.capitaldiecast.com/><span class=link>Capital Diecast</span></a>.</span><br><a href=media/consumer/consumer6.jpg><img height=121 width=420 src=media/consumer/thumb6.jpg border=0></a><br><P><span class=header>5 - Ultimate Control Console</span><span class=date> :: 04.22.04</span><br><span class=body>These folks designed and constructed this wonderful, modular cockpit specifically for Steel Battalion.  Of course you can use it for other uses but ... why the hack would you wanna do that?  Checkit: '<a href=http://www.ultimatecontrolconsole.com/home.html target=_new><span class=link>Ultimate Control Console</span></a>.'</span><br><a href=media/consumer/consumer5.jpg><img height=121 width=420 src=media/consumer/thumb5.jpg border=0></a><br><P><span class=header>4 - Freakin' Rad Helmet</span><span class=date> :: 02.26.04</span><br><span class=body>The Japanese Market for stuff like this actually exists.  That's why I'm a jealous man.  Brought to you by '<a href=http://www.proto-type.jp/ target=_new><span class=link>prototype</span></a>.'</span><br><a href=media/consumer/consumer4.jpg><img height=121 width=420 src=media/consumer/thumb4.jpg border=0></a><br><P><span class=header>3 - Personal Computing Environment</span><span class=date> :: 02.08.04</span><br><span class=body>Yeah; if by "Computing" you mean huge metal butt kicking.  <a href=http://www.mypce.com target=_new><span class=link>www.mypce.com</span></a>.</span><br><a href=media/consumer/consumer3.jpg><img height=121 width=420 src=media/consumer/thumb3.jpg border=0></a><br><P><span class=header>2 - Microsphere's M1 workstation</span><span class=date> :: 02.08.04</span><br><span class=body>This would work perfectly for a SB setup.  Check it out at <a href=http://www.microsphere.com target=_new><span class=link>www.microsphere.com</span></a></span><br><a href=media/consumer/consumer2.jpg><img height=121 width=420 src=media/consumer/thumb2.jpg border=0></a><br><P><span class=header>1 - Steel Armor Cockpit</span><span class=date> :: 02.08.04</span><br><span class=body>If you drive your VT like a racecar, this one's for you.</span><br><a href=media/consumer/consumer1.jpg><img height=121 width=420 src=media/consumer/thumb1.jpg border=0></a><br><P><span class=header>0 - Steel Battalion by Prototype</span><span class=date> :: 02.08.04</span><br><span class=body>The Steel Battalion specific getup made by '<a href=http://www.proto-type.jp/ target=_new><span class=link>prototype</span></a>.'</span><br><a href=media/consumer/consumer0.jpg><img height=121 width=420 src=media/consumer/thumb0.jpg border=0></a><br><P><P>
<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>