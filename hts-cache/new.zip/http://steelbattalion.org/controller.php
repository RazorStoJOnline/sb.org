<html><head><title>Steel Battalion :: Org \\ Controller</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420><img src='headerController.gif' height=34 width=348 alt='The Controller___________'>
<P>
<span class=body>To learn how to use the controller, check out the <a href=commTutorial.php><span class=link>Communications Tutorial</span></a>.</span>
<P>
<img src=controllerOld.jpg>
<P>
<span class=body>It's big.  In fact; these are the <a href=measureController.gif><span class=link>measurements</span></a>.  Below is the newer iteration of the controller; which is identical to the old one except for the blue coloration of the lights.</span>
<P>
<img src=controllerNew.jpg>
<P>
<span class=body>Here is a photo of both the old and the new controllers so you can see the subtle visual differences.  Click the image to zoom in; you'll see that the new controller has a grey matte finish to the metal plates rather than the black of the old controller.</span><P>
<a href=sideBySide.jpg><img src=sideBySideThumb.jpg border=0></a><P>
<span class=body>Other than the button and metal color differences, the connecting wires of the new controllers look a bit beefed up as you can see in the photo below.  Click to zoom.  Another difference between new and old is the stenciled lettering on the left side of the center block.  The old one said "P.R.F. Army 7th Special Panzer, blah blah" whereas the new one doesn't say P.R.F ... it just has the blah blah.  I'm guessing that's 'cause some people will be in factions other than the PRF, and boy would I be steamed if I was with the Right Brothers and it said PRF on my VT! (A small oversight on their part, or not wanting to recast the footpedal block; the new footpedals still say PRF army.  Take that!)</span><P>
<a href=plugs.jpg><img src=plugsThumb.jpg border=0></a>
<P>
<span class=body>The Controller for this game is half the fun of it.  So much so, that it certainly deserves to be spelled with a capital C.</span>
<P>
<a href=controllerGuts.jpg><img src=controllerGutsThumb.jpg border=0></a>
<P>
<span class=body>I took the center block of the controller apart just for kicks, and this is what it looks like.  Okay; I lied.  I got mad and smashed one of the buttons into itself and had to do emergency repairs; but this way YOU get to benefit from my stupidity!</span>
<P>
<a href=controllerDiagram.gif><img src=diagramThumb.jpg border=0></a>
<P>
<span class=header>Controller Functions</span><span class=date> (from left to right)</span>:
<P>
<img src=line.gif width=200 height=1 alt=_>
<P>
<table cellpadding=2>
<tr><td colspan=2 align=center><span class=header>Left Block</span></td></tr>
<tr><td align=right valign=top><span class=mini>GearShift:</td><td align=left valign=top><span class=mini>Just like your car.  Your automatic transmission car, that is.  R, N, 1, 2, 3, 4, 5*.</td></tr>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>Left JoyStick:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>Only moves left and right.  It controls the direction your mech faces.</td></tr>
<tr><td align=right valign=top><span class=mini>Hatswitch Thumbstick thing on Left ThumbStick:</td><td align=left valign=top><span class=mini>Moves 360 degrees, controls direction of external main camera.  Clicks in to return to center of mech's perspective.</td></tr>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>5 Toggle Switches:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>They just flick back and forth, and all they do is turn stuff on for the startup sequence.  Basically, a more complicated way of turning a key.  Quite silly if you ask me, but fun also.**</td></tr>
<tr><td colspan=2 align=center height=30><span class=header>Center Block</span></td></tr>
<tr><td align=right valign=top><span class=mini>Communicator Dial:</td><td align=left valign=top><span class=mini>Selects channel frequency.  Strangely, it just keeps rotating around in circles, the lines on its' edges don't mean squat.</td></tr>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>Communicator Buttons:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>Activate communication commands.</td></tr>
<tr><td align=right valign=top><span class=mini>F Buttons:</td><td align=left valign=top><span class=mini>They do different stuff depending on the mission you're on.***</td></tr>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>Tank Detach:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>If you have multiple gas tanks, and one empties, you can ditch it to decrease the weight load on your mech, abandoning the possibility of the tank getting refueled by the supply chopper.</td></tr>
<tr><td align=right valign=top><span class=mini>Override:</td><td align=left valign=top><span class=mini>The features of this function are threefold: (1) It makes your VT accelerate a LOT faster, and gives it a higher top speed (2) It fills up your battery almost instantly, so you can slidestep and fire your railgun all day long (3) It triples your gas consumption; so be careful.  Only available on 2nd Generation Mechs and above.</td></tr>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>Night Scope:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>I bet you can't guess what that button does.</td></tr>
<tr><td align=right valign=top><span class=mini>F.S.S.:</td><td align=left valign=top><span class=mini>Stands for "Forecast Shooting System."  Helpful for when you're locked onto a VT that's moving side to side; it'll fire your shots at where the VT will BE rather than where it WAS.  Rather clever.  Only available on 2nd Generation Mechs and above.</span>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>Manipulator:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>This activates your fun little arm with which you can pick up tanks and cows, and activate doors and switches. Disables your subweapon when active.</td></tr>
<tr><td align=right valign=top><span class=mini>Line Color Change:</td><td align=left valign=top><span class=mini>Changes the color of the HUD lines / text / other elements.  Sometimes it's helpful, usually it's annoying.</span>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>Washing:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>If you fall, or get hit by certain weapons, your camera's lense can get dirty; making it hard to see.  This'll squirt it and clean it so you're ready to rock.</td></tr>
<tr><td align=right valign=top><span class=mini>Extinguisher:</td><td align=left valign=top><span class=mini>If you get hit by certain weapons, the interior of your cabin can catch fire. Hit this button to extinguish the internal fire.  There's a siren on the HUD and the button will blink when it's needed.</span>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>Chaff:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>Use when an enemy VT or missile Spider launches a missile at you.  It'll surround your VT with a magical substance that makes missiles go bananas and fly elsewhere.  Not good against artillery.</td></tr>
<tr><td align=right valign=top><span class=mini>Main:</td><td align=left valign=top><span class=mini>Cycles through the main weapons you equipped.</span>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>Sub:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>Cycles through the sub weapons you equipped.</td></tr>
<tr><td align=right valign=top><span class=mini>Magazine Change:</td><td align=left valign=top><span class=mini>This'll reload your main weapon's magazine if the main weapon you have active has any extra magazines.</td></tr>
<tr><td colspan=2 align=center height=30><span class=header>Right Block</span></td></tr>
<tr><td align=right valign=top><span class=mini>Right JoyStick:</td><td align=left valign=top><span class=mini>This moves the crosshairs on the screen.  Super sensitive, especially when zoomed in.</span>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>Trigger on Right JoyStick:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>Fires subweapon.</td></tr>
<tr><td align=right valign=top><span class=mini>Lock On Button on Right JoyStick:</td><td align=left valign=top><span class=mini>Locks on to enemies that are lockonable ... like tanks are too small to lock onto, but other VTs will lock on fine.</span>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>Main Weapon Fire Button on Right JoyStick:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>Fires your main weapon.</td></tr>
<tr><td align=right valign=top><span class=mini>SubMonitor Open/Close:</td><td align=left valign=top><span class=mini>Open/Close toggle button for the little monitor on the top of the screen that contains your map and mission objectives, etc.</span>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>Map Zoom In/Out:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>Toggle zooms your map monitor.</td></tr>
<tr><td align=right valign=top><span class=mini>Mode Select:</td><td align=left valign=top><span class=mini>Changes the display on your top submonitor, between map and mission objectives, and what you've killed, etc.</span>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>SubMonitor Mode Select:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>Changes your lower submonitor to show either front, rear, ground, sky, or lock-on camera views.</td></tr>
<tr><td align=right valign=top><span class=mini>Camera Zoom In:</td><td align=left valign=top><span class=mini>Zooms your main camera view in.</span>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>Camera Zoom Out:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>Zooms your main camera view out.</td></tr>
<tr><td align=right valign=top><span class=mini>Eject:</td><td align=left valign=top><span class=mini>Only hit this when your mech is exploding.  Failure to do so will lose your game save.  Premature use of this will result in a lost mech, and you'll have to restart the level.</span>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>Cockpit Hatch:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>Startup Sequence: Closes the hatch.</td></tr>
<tr><td align=right valign=top><span class=mini>Ignition:</td><td align=left valign=top><span class=mini>Startup Sequence: Starts engine and weapon systems and operating system.</span>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>Start:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>Startup Sequence: Gets you going.  This is the button for the "mini game" part of the startup sequence.</td></tr>
<tr><td colspan=2 align=center height=30><span class=header>Foot Pedals</span></td></tr>
<tr><td align=right valign=top><span class=mini>Left Pedal:</td><td align=left valign=top><span class=mini>Slidestep pedal.  Use this to perform strafing slidestep move.  This one's key.  Also; it's as pressure sensitive as the others; pushing a little will make you slide a little; pushing a lot will make  you slide a lot.  Additionally; if you hit this button when in gears N, or 1-5 you'll slide forward if you don't hit the rotation lever.  If you're in gear R you'll slide backwards.  Combinations of gear and degree of turning the rotation lever will give you the ability to do diagonal slidesteps.</span>
<tr><td align=right valign=top bgcolor=eeeeee><span class=mini>Center Pedal:</td><td align=left valign=top bgcolor=eeeeee><span class=mini>Brakes!  Slow down!</td></tr>
<tr><td align=right valign=top><span class=mini>Right Pedal:</td><td align=left valign=top><span class=mini>Gas.  This makes you go.</span>
</td></tr></table>
<P>
<span class=date>*5th gear in Line of Contact puts you in "wheel mode" where you fly along on secret hidden wheels on your VTs toes propelled by jets at very high speeds.  It makes a great sound.</span><P>
<span class=date>**These switches actually have a purpose in Line of Contact.  When you shut them all off it'll turn your VT off, and make you invisble to radar and unable to be locked onto.  Good for ambushes.  Bad if they find you.</span><P>
<span class=date>***In Line of Contact, F1 is the 'sniper mode' button, F2 zooms in on your top submonitor, and F3 zooms in on your bottom submonitor.  If you push both F2 and F3 simultaneously it zooms in on the main screen.  All are very handy.</span>
<P>
<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>