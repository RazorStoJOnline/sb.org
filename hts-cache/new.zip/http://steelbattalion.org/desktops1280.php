<html><head><title>Steel Battalion :: Org  \\ Media</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420><img src='headerRecon.gif' height=34 width=348 alt='Recon___________'>
<P>
<span class=header>Steel Battalion Dot Org Desktops :: 1280 x 1024</span><br>
<a href=recon.php><span class=link>back to media</span></a>
<P>
<span class=header>14 - Tekki.jp Desktop</span><span class=date> :: 02.10.04</span><br><span class=body>A kickass prerendered image from tekki.jp.</span><br><a href=media/desktops/desktop1280_14.jpg><img height=121 width=420 src=media/desktops/thumb14.jpg border=0></a><br><P><span class=header>13 - Tekki.jp Desktop</span><span class=date> :: 02.10.04</span><br><span class=body>A kickass prerendered image from tekki.jp.</span><br><a href=media/desktops/desktop1280_13.jpg><img height=121 width=420 src=media/desktops/thumb13.jpg border=0></a><br><P><span class=header>12 - Tekki.jp Desktop</span><span class=date> :: 02.10.04</span><br><span class=body>A kickass prerendered image from tekki.jp.</span><br><a href=media/desktops/desktop1280_12.jpg><img height=121 width=420 src=media/desktops/thumb12.jpg border=0></a><br><P><span class=header>11 - Tekki.jp Desktop</span><span class=date> :: 02.10.04</span><br><span class=body>A kickass prerendered image from tekki.jp.</span><br><a href=media/desktops/desktop1280_11.jpg><img height=121 width=420 src=media/desktops/thumb11.jpg border=0></a><br><P><span class=header>10 - Tekki.jp Desktop</span><span class=date> :: 02.10.04</span><br><span class=body>A kickass prerendered image from tekki.jp.</span><br><a href=media/desktops/desktop1280_10.jpg><img height=121 width=420 src=media/desktops/thumb10.jpg border=0></a><br><P><span class=header>9 - Tekki.jp Desktop</span><span class=date> :: 02.10.04</span><br><span class=body>A kickass prerendered image from tekki.jp.</span><br><a href=media/desktops/desktop1280_9.jpg><img height=121 width=420 src=media/desktops/thumb9.jpg border=0></a><br><P><span class=header>8 - Tekki.jp Desktop</span><span class=date> :: 02.10.04</span><br><span class=body>A kickass prerendered image from tekki.jp.</span><br><a href=media/desktops/desktop1280_8.jpg><img height=121 width=420 src=media/desktops/thumb8.jpg border=0></a><br><P><span class=header>7 - Tekki.jp Desktop</span><span class=date> :: 02.10.04</span><br><span class=body>A kickass prerendered image from tekki.jp.</span><br><a href=media/desktops/desktop1280_7.jpg><img height=121 width=420 src=media/desktops/thumb7.jpg border=0></a><br><P><span class=header>6 - Tekki.jp Desktop</span><span class=date> :: 02.10.04</span><br><span class=body>A kickass prerendered image from tekki.jp.</span><br><a href=media/desktops/desktop1280_6.jpg><img height=121 width=420 src=media/desktops/thumb6.jpg border=0></a><br><P><span class=header>5 - Tekki.jp Desktop</span><span class=date> :: 02.10.04</span><br><span class=body>A kickass prerendered image from tekki.jp.</span><br><a href=media/desktops/desktop1280_5.jpg><img height=121 width=420 src=media/desktops/thumb5.jpg border=0></a><br><P><span class=header>4 - Tekki.jp Desktop</span><span class=date> :: 02.10.04</span><br><span class=body>A kickass prerendered image from tekki.jp.</span><br><a href=media/desktops/desktop1280_4.jpg><img height=121 width=420 src=media/desktops/thumb4.jpg border=0></a><br><P><span class=header>3 - Tekki.jp Desktop</span><span class=date> :: 02.10.04</span><br><span class=body>A kickass prerendered image from tekki.jp.</span><br><a href=media/desktops/desktop1280_3.jpg><img height=121 width=420 src=media/desktops/thumb3.jpg border=0></a><br><P><span class=header>2 - Tekki.jp Desktop</span><span class=date> :: 02.10.04</span><br><span class=body>A kickass prerendered image from tekki.jp.</span><br><a href=media/desktops/desktop1280_2.jpg><img height=121 width=420 src=media/desktops/thumb2.jpg border=0></a><br><P><span class=header>1 - Tekki.jp Desktop</span><span class=date> :: 02.10.04</span><br><span class=body>A kickass prerendered image from tekki.jp.</span><br><a href=media/desktops/desktop1280_1.jpg><img height=121 width=420 src=media/desktops/thumb1.jpg border=0></a><br><P><span class=header>0 - Desktop 01</span><span class=date> :: 02.07.04</span><br><span class=body>Steel Battalion Dot Org's First Desktop.</span><br><a href=media/desktops/desktop1280_0.jpg><img height=121 width=420 src=media/desktops/thumb0.jpg border=0></a><br><P><P>
<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>