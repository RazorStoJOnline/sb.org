<html><head><title>Steel Battalion :: Org</title>
<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420><img src=welcome.jpg><P>
<!----------------------------- one section ----!>
<span class=header>Killzone 3 Exoskeletons are rad.</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>02.04.11</span><P>
<span class=body>The Killzone 3 Exoskeletons make a dope study for how a new Steel Battalion could be made using motion control.  I hate motion control, but in this case I think I could definitely make an exception.  And by "this case" I mean my imagination.<br><br>Link: <a href=http://www.youtube.com/watch?v=QVF18EWgsuE>http://www.youtube.com/watch?v=QVF18EWgsuE</a><p>

<iframe title="YouTube video player" width="560" height="345" src="http://www.youtube.com/embed/QVF18EWgsuE" frameborder="0" allowfullscreen></iframe>

<P>
<!----------------------------- one section ----!>
<span class=header>New Steel Battalion: Heavy Armor game for XBox 360 and Kinect?!</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>09.16.10</span><P>
<span class=body><a href="http://www.joystiq.com/screenshots/steel-battalion-heavy-armor-kinect/3368225/#/0">Check this out</a>. My first reaction was "HOLY CRAP THIS IS AWESOME!"  And then I was excited.  And then I thought about it and was concerned about the control scheme using Kinect instead of The Controller.  And then I watched the video, and the VTs look less like Steel Battalion and more like Chrome Hounds.  I think this needs much discussion in <a href="http://lineofcontact.net/forums/index.php">the forums</a>.<P>
<!----------------------------- one section ----!>
<span class=header>Steel Battalion at PAX!</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>03.28.10</span><P>
<span class=body><a href="http://www.wired.com/gamelife/2010/03/pax-steel-battalion/">This is awesome!</a> They had a 5 v 5 LAN setup at PAX (Penny Arcade Expo) Boston this spring.  If I had known this was going to happen, I'd have bought tickets.<P>
<!----------------------------- one section ----!>
<span class=header>Happy birthday, LOC!</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>02.27.08</span><P>
<span class=body>What game has the staying power of LoC?  Nothing.  We still play, <a href=http://www.merccorp.com/sbc/sborg/index.php>we still scheme</a>, and we are still learning things about this incredible game.  Word to all of your moms.<P>
<!----------------------------- one section ----!>
<span class=header>Two Years Later ... Steel Battalion Lives!</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>03.19.07</span><P>
<span class=body>Just a friendly neighborhood reminder that there are still a ton of pilots out there playing this game.  Just log on and play!  You'll see!  There are 3 games going on at this very moment as a matter of fact.<P>
<!----------------------------- one section ----!>
<span class=header>A Smidge of Good News</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>09.08.05</span><P>
<span class=body>It's official; they are going to be deploying a patch to unlock everything for free mode.  KingLeerUK alerted me to a post on the capcom forums where the following was stated:<P>
<span class=body>"I am happy to report that we plan to release a patch to unlock the items acquirable only by going online. We hope to have this patch available sometime shortly after the closure of Online Campaign Mode."<br>
-WickedKitty<P>
<!----------------------------- one section ----!>
<span class=header>It's a sad sad sad sad sad sad sad sad world</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>09.03.05</span><P>
<span class=body>Looks like Capcom has decided to take down the campaign servers at the end of the month.  It's a true shame.<P>
<span class=body>"As of Friday September 30th, 10:00AM-12:00PM PST, Capcom will be ending the online services for Campaign Mode of Steel Battalion. We appreciate your continued support of our product, and sincerely apologize for any inconveniences this may cause. Thank you for your understanding of this matter.<P>
<span class=body>However, we will continue services and support for both Free Mission Mode and System Link play."</span><P>
<!----------------------------- one section ----!>
<span class=header>Line of Contact Dot Net</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>02.06.05</span><P>
<span class=body>There is some data on sb.org about line of contact.  There is also plenty of data on the Game on <a href=http://www.lineofcontact.net><span class=link>Line of Contact Dot Net</span></a>.  And by "plenty" I mean more than you could possibly freakin' imagine.  Thanks and props to KingLeerUK for the amazing site.  Check it out!</span><P>
<!----------------------------- one section ----!>
<span class=header>The Command Station</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>02.04.05</span><P>
<span class=body>Just added another great consumer controller stand built for steel battalion to the <a href=consumer.php><span class=link>media section</span></a>.  It's the kickass <a href=http://www.capitaldiecast.com/><span class=link>Command Station</span></a> built by <a href=http://www.capitaldiecast.com/><span class=link>Capital Diecast</span></a>.</span><P>
<!----------------------------- one section ----!>
<span class=header>The Verdict is IN</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>11.11.04</span><P>
<span class=body>Halo 2 is out, and it is officially NOT devoid of giant devastating robots.  For this I give Halo 2 a high 5.  It has, however, officially made everyone stop playing LoC -- and for that I give Halo 2 a big F off.</span><P>
<!----------------------------- one section ----!>
<span class=header>Capcom Updated Something.  SERIOUSLY!!</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>09.01.04</span><P>
<span class=body>Apparently, today when you start up the game, it'll ask you to download an update.  And yes ladies and gentlemen; the update is actually a minor (or major ... depending on how you look at it) network code fix.  Some people who could not play at all in the past have reported being able to play.  It's still a silly bandwidth hog (4 vs 4 and 5 vs 5 in your dreams you sissy) ... but it's opening its doors to more users with varying ISPs.  So THAT is certainly something to sing about.  Tralalala.</span><P>
<!----------------------------- one section ----!>
<span class=header>New Setups Added</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>07.10.04</span><P>
<span class=body>I added DWraith's setup, and updated mine since I've moved.  Check 'em out in the <a href=setups.php><span class=link>setups</span></a> section.</span><P>
<!----------------------------- one section ----!>
<span class=header>Some VERY cool Drawings</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>07.03.04</span><P>
<span class=body>Just uploaded some amazing <a href=drawings.php><span class=link>drawings</span></a> of weapons to the concept drawing section of the <a href=recon.php><span class=link>media section</span></a>.</span><P>
<!----------------------------- one section ----!>
<span class=header>Finally!  An update!</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>06.29.04</span><P>
<span class=body>Well, since tonberry asked for it in the <a href=http://www.steelbattalion.org/forum/viewtopic.php?t=424><span class=link>forums</span></a> I figured I'd get myself together and finish the <a href=vts2.php><span class=link>VT Catalog</span></a> now that all the VTs are out.  And have been for months.  Shut up.  So everything's in there, I'm just missing some info on a couple weapons and images of the Earthshaker and the Jaralaccs NS-R that don't suck.  Rock!</span><P>
<!----------------------------- one section ----!>
<span class=header>An apology.</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>04.16.04</span><P>
<span class=body>I recognize that it's been 3 weeks since my last update, and there are some massive gaping holes in all of the exciting elements of the site; like the VT catalog, and the map list etc.  I'm still waiting to close on my apartment, so I'm homeless and haven't turned on an xbox in 3 weeks.  I'm using Starbucks' bandwidth to write this.  So please forgive me, and know that updates are coming.  I miss you all dearly.</span><P>
<!----------------------------- one section ----!>
<span class=header>Maps are rad.</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>03.25.04</span><P>
<span class=body>For those of you who don't have the game (YET), I put up a section showing the <a href=locMaps.php><span class=link>maps</span></a> from Line of Contact.  You can get to it from the <a href=warfare.php><span class=link>online:loc page</span></a>. Also, "they" released a whole mess of new VTs (with some sexy new weapons) so the VT Catalog has been updated.  I'm still missing the Rapier.</span><P>
<!----------------------------- one section ----!>
<span class=header>Mercenaries ROCK.</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>03.25.04</span><P>
<span class=body>The Jarlaccs Mercenary Forces are in the house, and they're ready to rupture your cockpit, so get out there and rock.  Their VTs and kick ass weapons have been added to the VT Catalog.</span><P>

<!----------------------------- one section ----!>
<span class=header>This Feature is cooler than That feature.</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>03.18.04</span><P>
<span class=body>I toiled for hours in the basement hindered only by the rats to bring you the <a href=vts2compare.php><span class=link>VT comparing thing</span></a> I hope you like it!</span><P>
<!----------------------------- one section ----!>
<span class=header>We were all new to this game at some point ...</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>03.17.04</span><P>
<span class=body>The good "DareDevil" has blessed us with an article about how to kick ass if you're a n00b.  You can find it <a href=n00b.php><span class=link>here</span></a> or by clickin' the link to it from the <a href=manual.php><span class=link>manual page</span></a>.  Oh; and today we will finally put to rest the rumors about the 2nd generation VTs being released.  See you online for some override duels!</span><P>
<!----------------------------- one section ----!>
<span class=header>Funtimes All Around</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>03.11.04</span><P>
<span class=body>Now "they" have told us that they shall officially take the game down every day for a half an hour' from 6:30am to 7:00am.  They've also acknowledged that their game is seriously F'd up; as stated at <a href=http://www.tekki.jp><span class=link>tekki.jp</span></a>.  And I quote: "Being trouble at the time of campaign mode playing has been ascertained, presently we do the correction job."  Lord knows I'm comforted!  No, really! <a href=warfare.php><span class=link>read more ...</span></a></span><P>
<!----------------------------- one section ----!>
<span class=header>Right Brothers are in the HOUSE!</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>03.11.04</span><P>
<span class=body>"They" just released the Right Brothers Faction into the fray.  Their initial VT is the <a href=vts2.php#Colt><span class=link>Colt</span></a>.  They aren't particularly great VTs, but they do have Marker Rounds.  That is very cool.  Also available are new Scare Face A1's, and Colt Executives.  More info on 'em all in the <a href=vts2.php><span class=link>VT Catalog</span></a>.  Rock out.</span><P>
<!----------------------------- one section ----!>
<span class=header>More Fixes Coming.  And some Goodies.</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>03.06.04</span><P>
<span class=body>Seriously.  Check out the <a href=warfare.php><span class=link>Online:LoC</span></a> section for a wonderful translation of the latest update they're planning on march 7th (from tekki.jp -- because capcom USA doesn't know how to use a translator, or change its web page).  In other news, I rebuilt the warfare section so it's now more organized, and added a <a href=commTutorial.php><span class=link>Communications Tutorial</span></a> section because I know a lot of people are confused about how the hell to talk to people in the middle of a match.</span><P>
<!----------------------------- one section ----!>
<span class=header>A Happy Scheduled Maintenence.</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>03.04.04</span><P>
<span class=body>I can only hope that by "maintenence" they mean "we're fixing the busted game we released."  If so, then woot dang!  It's battle time!  Taken from tekki.jp, and posted in the forums by Sierex (translated lusciously by Babelfish):</span><P>
<span class=date>< Maintenance day and time ><br>
March 5th (the gold) from 6 o'clock in the morning 1 hour to 7 o'clock :: Inconvenience annoyance is applied, but that no soldier/finishing acknowledgement, we ask. Furthermore, usually sort you can enjoy concerning free play mode and system link mode.</span><P>
<span class=body>We've decided that 6 o'clock is probably GMT, so that means that by tomorrow we'll either notice some changes or need another cheesesteak.<P>
<!----------------------------- one section ----!>
<span class=header>Because I hate hating.</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>02.29.04</span><P>
<span class=body>In the <a href=warfare.php><span class=link>Online:LoC</span></a> section I put some information regarding the LoC connectivity issues.  I'll post whatever news I have regarding the progress if this problem there. And probable here.  And probably on the <a href=forum/><span class=link>forums</span></a> as well.</span><P>
<!----------------------------- one section ----!>
<span class=header>Updates and stfu.</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>02.29.04</span><P>
<span class=body>I put up some <a href=screenshotsLOC.php><span class=link>fun images</span></a> of BoxCar and me doing some damage to a poor soul in a Vitzh.  Campaign mode still seems busted, but fortunately the Japanese seem to know, and have fessed up to the game having serious problems.  This is a good thing (thanks to <a href=http://www.steelbattalion.org/forum/viewtopic.php?t=125><span class=link>Abou 3bbas</span></a> for easing my heart).  Update: I overhauled the <a href=controller.php><span class=link>controller</span></a> section to include pics of the old and new controllers side by side, and a new diagram of the entire controller, as well as adding LoC functionality to the button explanations via asterisks.  Clever, I know.  I'm also slowly but surely eliminating all the parts of the  page that have "speculative" information about the game, except where still applicable (like anything regarding Jarlaccs and Right Brothers etc).</span><P>
<!----------------------------- one section ----!>
<span class=header>The Game.  THE GAME.</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>02.27.04</span><P>
<span class=body>Okay; so FINALLY many of us got our hands on the game today.  I played for 14 hours straight, I'm proud to say.  I'll be working on a full review soon; but at the moment I'll just say this: The game freakin' rocks.  There are some MAJOR disappointments in many areas of the game, but once you get used to them (like not playing campaign mode AT ALL) the free missions are an absolute blast.  In other news, there's an interview with me (whoa!  Me?!) over at <a href=http://www.xequted.com/><span class=link>xequted.com</span></a>.  Check it out and read all about "it" and stuff.<a href=http://www.xequted.com/interviews.php?subaction=showfull&id=1077908027&archive=&start_from=&ucat=10&><span class=link>The Interview</span></a>.  Wee!</span><P>
<!----------------------------- one section ----!>
<span class=header>Stuff hither and thither.</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>02.26.04</span><P>
<span class=body>Well, it's D-Day and we're all waiting patiently (or not so patiently) for our EBGames Shipment to arrive, or for the UPS folks to arrive with our little green package.  I figured I'd fill my time by looking for some new bits of SB fun online, rather than sitting here twiddling my thumbs.  I've found some <a href=toys.php><span class=link>toys</span></a> and a crazy piece of <a href=consumer.php><span class=link>hardware</span></a>.  Enjoy!</span><P>
<!----------------------------- one section ----!>
<span class=header>Another Movie, The Brits show off their goods...</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>02.22.04</span><P>
<span class=body>The_tonberry_killer was good enough to send some images of the UK packages, so I put 'em up in the <a href=product.php><span class=link>products</span></a> section. I also got curious about falling off a cliff, so I put a movie up of myself going straight off a cliff in mission 2 in the <a href=moviesSB.php><span class=link>SB Movies</span></a> section.  Check it out if you are also curious.</span><P>
<!----------------------------- one section ----!>
<span class=header>Considerable Swanky Updates</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>02.13.04</span><P>
<span class=body>I updated and enhanced the <a href=vts.php><span class=link>VT Catalog</span></a> section to now have cross-referenceable weapon lists, with info on each weapon.  Fun! I added some drawings I've done of VTs in a <a href=doodles.php><span class=link>doodles</span></a> section, accessible from the <a href=recon.php><span class=link>media section</span></a>.</span><P>
<!----------------------------- one section ----!>
<span class=header>New Content and Section</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>02.10.04</span><P>
<span class=body>Check out the brand spankin' new <a href=vts.php><span class=link>VT Catalog</span></a> section! Finally uploaded controller Dimensions in the <a href=controller.php><span class=link>controller</span></a> section. Found a billion kick ass desktops at tekki.jp and brought them over <a href=recon.php><span class=link>here</span></a> for your pleasure.</span><P>
<!----------------------------- one section ----!>
<span class=header>New Features and Content</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>02.08.04</span><P>
<span class=body>There is now a section on community setups in the media section. </span><a href=recon.php><span class=link>Check it out!</span></a><span class=body> If you want your setup to be included please email me your pic(s) and a couple sentences about your setup. Also there are some new products in the consumer products section (also on the <a href=recon.php><span class=link>media</span></a> page), some of which I was alerted to on another new Steel Battalion site: <a href=http://www.steel-battalion.net><span class=link>steel-battalion.net</span></a>.  Go check out their site and support the Steel Battalion community.  Rock!</span><P>
<!----------------------------- one section ----!>
<span class=header>Welcome to the new steelbattalion.org.</span><br><img src=greyPixel.gif width=100% height=1><br><span class=date>02.06.04</span><P>
<span class=body>If you don't already know, Steel Battalion is that kick ass mech game with the huge crazy controller that nobody believes actually exists.<br>If you don't know anything about Steel Battalion, or are skeptical about the game, check out the "Why Buy It?" section.<br>If you're already part of the Steel Battalion community, welcome to yet another fansite.  Thanks for visiting! If you've got questions or comments, you can contact me at <a href=mailto:info@steelbattalion.org><span class=link>info@steelbattalion.org.</span></a></span><P>
<span class=body>Enjoy.</span><P>
<!----------------------------- one section ----!>
<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>