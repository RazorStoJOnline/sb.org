<html><head><title>Steel Battalion :: Org \\ links</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420><img src='headerRecon.gif' height=34 width=348 alt='___________'>
<P>
<span class=header>Links!</span><br>
<span class=body>These are the sites on the 'net that are dedicated to the game we love.  I'm not even going to give you Capcom's site because it'll just make you angry.</span>
<P>
<span class=body>Line Of Contact Dot Net : <a href=http://www.lineofcontact.net target=_new><span class=link>www.lineofcontact.net</span></a></span><font color=white>No Pants Now!</font><br>
<span class=date>The dopest most info-packed site on the planet; brought to you by our friend KingLeerUK and the letter F.</span>
<P>
<img src=greyPixelLight.gif width=147 height=1>
<P>
<span class=body>Tekki Dot JP : <a href=http://www.tekki.jp/ target=_new><span class=link>www.tekki.jp</span></a></span><br>
<span class=date>If you can read Japanese this site will probably be helpful.</span>
<P>
<img src=greyPixelLight.gif width=147 height=1>
<P>
<span class=body>"The French Site" : <a href=http://steel.battalion.free.fr/steelbattalion.htm target=_new><span class=link>steel.battalion.free.fr</span></a></span><br>
<span class=date>It's in French.  It's also got a very spiffy interface.  And pictures.  And I think it's updated more often than my site is; which isn't saying much.</span>
<P>
<img src=greyPixelLight.gif width=147 height=1>
<P>
<span class=body>Steel Battalion Central : <a href=http://urbanlegends.about.com/ target=_new><span class=link>sbc.pippin.us</span></a></span><br>
<span class=date>This used to be the greatest site on the internet.  Now it's nothing more than a myth.</span>
<P>
<img src=greyPixelLight.gif width=147 height=1>
<P>

<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>