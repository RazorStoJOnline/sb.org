<html><head><title>Steel Battalion :: Org \\ Online Warfare</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420><img src='headerWarfare.gif' height=34 width=348 alt='Warfare___________'><br><span class=body>Line of Contact Warfare Section ::</span><br><a href=warfare.php><span class=link>Back to Warfare Main</span></a><P>
<span class=header>VT Customization</span><br><img src=greyPixel.gif width=100% height=1><P>
<span class=body>You can add little insignias to the armour of your VT (it appears somewhere on the right shoulder of your VT), and affect certain characteristics of the armour's colour and pattern (Forest, Desert, and City Camoflage options).  You can define the colour of individual parts of the VTs body (Upper Body, Lower Body, Right Shoulder, Left Shoulder, Upper Leg, Lower Leg, etc.  tons of options) using an HLS (Hue / Saturation / Lightness) control.</span><P>
<img src=sexier.jpg><p>
<span class=header>Insignias:</span><br><span class=body>The insignias are tradeable online.  You build them in a funny little "mspaint" application built into the game.  The insignias are 64 x 64 pixels, and can have transparency.  The initial greenish / bluish color is the "transparent" color.</span><P>
<img src=insignias.jpg><P>
<span class=body>This is the funny little paint application.  I've actually found it to be more powerful than I was ever expecting.  Kinda like Serpentor or Unicron.</span><P>
<img src=marioPaint.jpg><P>
<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>