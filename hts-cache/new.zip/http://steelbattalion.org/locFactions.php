<html><head><title>Steel Battalion :: Org \\ Online Warfare</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420><img src='headerWarfare.gif' height=34 width=348 alt='Warfare___________'><br><span class=body>Line of Contact Warfare Section ::</span><br><a href=warfare.php><span class=link>Back to Warfare Main</span></a><P>
<span class=header>Factions:</span><br><img src=greyPixel.gif width=100% height=1><P>
<span class=body>Factions are huge in the online campaign gameplay mode.  If you want to play WITH your friends, you're all going to have to choose the same faction so you can fight side by side; unless some of you choose Jarlaccs; they fight with whomever they want on a per match basis.  When playing "free mission" mode, you can change factions on a whim.  There are 4 factions to choose from:</span><P>
<span class=body>Pacific Rim Forces (PRF)</span><span class=date> - the good guys from the original game; now an oppressive regime.</span><br>
<span class=body>Hai Shi Dao (HSD)</span><span class=date> - the bad guys from  the original game, now freedom fighters trying to regain their country and culture.</span><br>
<span class=body>Right Brothers (RB)</span><span class=date> - a new faction introduced for LoC.  They are guerillas. These folks have unique VTs; like the sheepdog.</span><br>
<span class=body>Jarlaccs (JAR)</span><span class=date> - a mercenary force that fights with whichever team they want to, because money is more important than pride.</span><p>
<span class=body>You'll start with one VT from your faction.  As you progress through the campaign mode online, you'll unlock more VTs within your faction (Or as time goes by "they" will just make new VTs available).  Each faction has specific VTs they can pilot.  The first VT each faction starts off with is as follows:</span><P>
<span class=body>PRF :: </span><a href=vts2.php#Decider><span class=link>Decider</span></a><br>
<span class=body>HSD :: </span><a href=vts2.php#Vitzh><span class=link>Vitzh</span></a><br>
<span class=body>RB :: </span><a href=vts2.php#Colt><span class=link>Colt</span></a><span class=date> (as of 03.11.04)</span><br>
<span class=body>JAR :: </span><a href=vts2.php#Jarlaccs_C><span class=link>Jarlaccs C</span></a> <a href=vts2.php#Jarlaccs_N><span class=link>Jarlaccs N</span></a><span class=date> (as of 03.24.04)</span><P>
<span class=body>To see all of the VTs each faction has; check out the <a href=vts2.php><span class=link>VT Catalog</span></a>.</span><P>
<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>