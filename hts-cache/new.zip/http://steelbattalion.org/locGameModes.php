<html><head><title>Steel Battalion :: Org \\ Online Warfare</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420><img src='headerWarfare.gif' height=34 width=348 alt='Warfare___________'><br><span class=body>Line of Contact Warfare Section ::</span><br><a href=warfare.php><span class=link>Back to Warfare Main</span></a><P>
<span class=header>Online Game Modes</span><br><img src=greyPixel.gif width=100% height=1><P>
<span class=body>There are two ways to play this game. Campaign, and Free Mission.  Within Campaign there is 1 mode: team battle.  Within Free Mission Mode there are many modes; Team battle, Battle Royale (Deathmatch) and Capture the Container (flag).</span><P>
<span class=header>Campaign Mode</span><br>
<span class=body>Campaign mode is where you earn combat points (basically experience - levels you up so you can unlock mechs) and supply points (basically money - for purchasing mechs that you unlock or destroy). Campaign mode is also where you have to worry about ejecting and losing mechs etc, if you don't eject and you get killed, your character is destroyed, and you have to start again from scratch.  Another cool thing about Campaign mode is that every battle is a part of a greater war.  After each match the results are uploaded to a central server, and the wins and losses affect your factions status in the war (more about factions later).  The war standings are reset regularly to keep one team from running away with it all.</span><P>
<span class=body>Stealing VTs.</span><br>
<span class=body>You can steal an enemy VT during a campaign battle by shooting out the legs of the enemy VT.  This is hard to do, because in order to hit a VTs legs, you have to disengage your weapon lock and aim manually.  Doesn't sound TOO hard, but if you're trying to steal a kick ass mech from someone; chances are they earned it and are good pilots.  Additionally, if you damage too much of the body section of the VT you're trying to capture, you'll destroy it and render it useless.  It'll be tough.  But fun.</span><P>
<span class=body>Trading VTs and weapons.</span><br>
<span class=body>You can trade VTs, weapons, powerups, insignia, and supply points with any of your friends online.  It's pretty cool.  The tradeable powerups are rare, and seem to be distributed kinda randomly.  Rumer has it you can get them by blowing up crates near spawn points ...</span><p>
<span class=header>Free Mission Mode</span><br>
<span class=body>Free Mission mode is where you play against friends and aren't involved in the greater world battle, and you don't gain / lose supply points.  In any of the Free modes (Team Battle, Battle Royale, Capture the Container), you can use any VT you have unlocked playing Campagin mode (or any VT someone traded to you in Campaign mode and you traded back instantly.  Yes; that works.).  You don't lose these VTs if you lose a pilot to Death in campaign mode.<span><P>
<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>