<html><head><title>Steel Battalion :: Org  \\ Manual</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420><img src='headerManual.gif' height=34 width=348 alt='Manual__________'>
<P>
<span class=header>n00b articles by Daredevil</span><br>
<span class=date>For those of us who haven't memorized the button placement on the controller yet.</span><P>
<a href=n00b.php><span class=link>n00b Advice</span></a><span class=body> - Basics</span><br>
<a href=n00b2.php><span class=link>n00b Encouragement</span></a><span class=body> - Multitasking and Interface</span><p>
<span class=header>Game Modes</span>
<P>
<span class=body>There are two ways to play this game.  Campaign, and Free Mission.</span>
<P>
<span class=body>Campaign mode is where you earn combat points (basically experience - levels you up so you can unlock mechs) and supply points (basically money - for purchasing mechs that you unlock).  Campaign mode is also where you have to worry about ejecting and losing mechs etc, because if you run out of money your character is destroyed, and if you don't eject and you get killed, your character is destroyed.  In both cases you have to start again from scratch.</span>
<P>
<span class=body>Free Mission mode is where you can just mess around practicing on all the levels you've beaten using the mechs you've unlocked.  If you don't eject you don't lose anything, and if you lose mechs,  you don't have to pay to replace them.  Feel free to experiment in this mode because there are no penalties.</span>
<P>
<span class=header>The Startup Sequence</span>
<P>
<span class=body>The startup sequence in this game is both really fun and really silly.  There is a sequence of 2 buttons to push, then 5 switches to flick, then a 3rd "start" button which is presented as a sort of "mini game."</span>
<P>
<img src=startup.jpg>
<P>
<span class=body>See those 5 bright bars in the middle of the screen?  They all have to be past that white line when you push the "start" button, or else the VT will stall and you'll have to wait a moment.  It's no big deal in the offline game, but in Line of Contact (LOC) while you're starting up you're vulnerable to enemy fire.  So you don't want to be sitting there messing with the ignition when there's butt to be kicked.</span>
<P>
<span class=header>The Heads Up Display (HUD)</span>
<P>
<span class=body>The HUD changes depending on the generation of the mech you're piloting.  Though the look and layout changes, everything's exactly the same, you're just going to have to learn the different places to find things.  In Line of Contact, there are different HUDs for support VTs as well as the normal ones; they have bigger maps and are more suited to their support role.  But again, it's all the same stuff - just in different places.</span>
<P>
<img src=cockpit1stGen.jpg>
<P>
<img src=cockpit2ndGen.jpg>
<P>
<img src=cockpit3rdGen.jpg>
<P>
<span class=body>So there's no big difference between the 1st and 2nd generation cockpits, then there's a clear leap to VERY FREAKING COOL for the 3rd generation.  Not only is there a much greater field of view, but there are sexy blue lights.  And everybody loves a digital display.  The one thing that gets annoying about the 3rd generation HUD is sometimes it's tough to read what weapon you've got activated because the words are superimposed on the screen.  That's one of the things I like best about the 1st Gen HUD - you can see what weapon's activated, and if you're forgetful (yup!) you can see what weapon you've got on deck.  Good Times.
<P>
<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>