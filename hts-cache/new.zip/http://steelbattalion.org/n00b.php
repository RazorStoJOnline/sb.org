<html><head><title>Steel Battalion :: Org \\ n00b help</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420>
<img src=headerNoob.gif><P>
<span class=body>My name is Daredevil and I am a Steel Battalion n00b.  A real n00b, like I-Just-Got-The-Game-Two-Weeks-Ago n00b.  </span><P>
<span class=body>And just to be clear, I'm not some whiz kid with the gift of youthful dexterity, but a 41 year-old business owner, father of three young boys who loves playing games, and enjoys the struggle associated with getting good at this game.</span><P>
<span class=body>There are many aspects to this game that are intimidating, and let's not be afraid to admit that this is so.  At the same time, I think there are some things that most of us n00bies need to keep in mind when playing/practicing.  Hopefully, some of the things I've stumbled across and read elsewhere can help other pilots who are in the same boat as I.</span><P>
<span class=body>You have to crawl before you can walk and walk before you can run, so we're gonna "Steel Battalion" before we "Line of Contact."  Capice?</span><P>
<img src=n00bImage.jpg><p>
<span class=body>So here goes ...</span><P>
<span class=body>First of all, my pilot name aside, I am far from a risk-taker when it comes to Steel Battalion.  n00b + Risk Taker = Dead when it comes to this game.  And if any of you have visited <a href=http://sbc.pippin.us target=_new><span class=link>Steel Battalion Central</span></a> and watched the videos of the walk throughs (they are more like run throughs) you get the definite impression that beginners should try to get through these levels as fast as you can.  This couldn't be further from the truth.</span><P>
<span class=body>That being said, you will die a lot at first.  And n00bies should die as it's part of the steep learning curve.  Just accept it as an inevitable part of this game, but learn from your deaths.  And if you follow some of these guidelines your deaths won't be in vain!</span><P>
<span class=body>So the first general tip that I have is to take your time and be patient.  Most of the levels give you plenty of time to be cautious and to play the game at a reasonable pace.  Simple enough as an overall philosophy, so let's talk about some ways to apply this thinking to the game-play.</span><P>
<span class=body>A great way to play through the game for the first time is to create two pilots, one at the normal setting and one at the rookie setting.  This allows you to acclimate yourself to each level.  After you complete the level as a rookie, go back to "Free Mission Mode" and practice, practice, practice, then use your "Normal" pilot and play through the level against the tougher opposition.</span><P>
<span class=body>Playing "Free Mission Mode" is incredibly useful.  First of all you are freed from the worries of losing your pilot (but don't let this make you sloppy.  ALWAYS hit eject when you need to).  Second, you can try to perfect your tactics and incorporate different tactics to accomplish your mission without the inconvenience of death.  Third you can become familiar with the use of other <a href=vts.php><span class=link>VT's</span></a>, and the strategic and tactical advantages and disadvantages of each.</span><P>
<span class=body>Remember that despite being considered a "simulation" Steel Battalion is still a game, and a game is supposed to be fun.  I actually have as much fun going back to "Free Mission Mode" and trying new things as I have had in the "Campaign Mode."</span><P>
<span class=body>Using Level Three as an example, I found that if you use a Falchion (or Blade or Prominence when unlocked) and sprint your way over the bridge, shooting but avoiding confrontation down the main road, and get to the mission area without suffering any damage, you will get more points than if you clear the board of all VT's.  The whole thing takes about two minutes, and not only won't you use a supply run, you will get 3500 points for taking no damage.  Pretty cool.</span><P>
<span class=body>Next let's talk about some VT technique issues.  How many of you shoot and wait 'til you see the shot hit its target before moving on to another enemy?  I used to do it all the time, and who could blame me?  I loved the sound of the Smooth Bore firing and loved watching it take out its target.  The problem is when there are multiple enemies around you can get taken out while you're busy admiring the results of your marksmanship.</span><P>
<span class=body>Using the "<a href=fieldNotes.php#1><span class=link>Clear the Beachhead</span></a>" Mission as an example, when you come upon the three Vitzhs and two Giraffes as you clear the first series of barriers, quickly target Giraffe A and shoot and immediately do the same for Giraffe B.  In the time it takes to do this (one thousand one, one thousand two, one thousand three) you will have taken out two stationary targets and moved on to the moving ones.  And don't shoot if you aren't in range!</span><P>
<span class=body>When facing moving targets this tactic becomes more important as you can take advantage of the "knock downs" that result from a good shot.  For this "knock down effect" I favor the <a href=weaponsMain.php#315-tr><span class=link>315 Twin Rifle</span></a> over the <a href=weaponsMain.php#315-sb><span class=link>same caliber Smooth Bore</span></a>.  The <a href=weaponsMain.php#315-tr><span class=link>315-TR</span></a> packs a punch that knocks targets down with more frequency, and even though it weighs more and has slightly less range than the <a href=weaponsMain.php#315-sb><span class=link>315-SB</span></a>, these "disadvantages" are more than made up for by your ability to disable opponents and take them out while they are no threat to you.</span><P>
<span class=body>When you are outnumbered, as is the case in the final area of the "<a href=fieldNotes.php#4><span class=link>Sink the Battleship Mission</span></a>" this tactic can be the difference between winning and losing.</span><P>
<span class=body>One last bit of advice before we wrap it up here is to not get seduced by the <a href=weaponsSub.php#205-PT><span class=link>Plasma Torch</span></a>.  Granted it looks as cool as all heck to use, and there's nothing more macho than charging into your opponent and knocking it to the ground.  But the problem is that you have to be lined up straight towards your target to make it work.  Given that you should be circling around your opponent with your camera facing in, maneuvering your VT to get properly lined up can be tough for us neophytes.  Until you are on the mission where you need to get into the warehouse you can practice in "Free Mission," but don't worry too much about the <a href=weaponsSub.php#205-PT><span class=link>PT</span></a>.</span><P>
<span class=body>A little load out advice, stay at the recommended weight by using the <a href=weaponsMain.php#315-tr><span class=link>315-TR</span></a> and pass on the <a href=weaponsSub.php#205-PT><span class=link>Plasma Torch</span></a> especially on the "<a href=fieldNotes.php#4><span class=link>Battleship Mission</span></a>," you won't be disappointed.</span><P>
<span class=body>Well I hope this has helped.  All I know is that after just two weeks of playing SB, the first eight missions are now very beatable thanks to some practice and a lot of patience mixed in with a little bit of discipline.  Keep checking back for more tips and never hesitate to <a href=/forums/><span class=link>ask for help</span></a>!</span><P>
<span class=date>-Daredevil</span><P>

<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>