<html><head><title>Steel Battalion :: Org \\ n00b help</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420>
<img src=headerNoob.gif><P>
<span class=body>Hi all, Daredevil here.  Still a noob? I am.  I'm stuck on Mission 9, but I swear I'm getting better.  In all honesty, between "March Madness" and the madness associated with having 5 month-old twin boys, I've only had time to get wiped out twice by the Regal Dresses ... but I'll be back.  </span><P>
<span class=body>And no I still can't LOC, 'cause I either get dropped due to connectivity issues or noob issues.</span><P>
<span class=body>But I've still learned a lot, and here's another installment of "Steel Battalion for Dummies and Noobs."</span><P>
<span class=body>Multitasking is a way of life when you are a VT pilot, and whether you like to be swift and deadly or plodding and deadly, you need to be able to do at least three things at once, or die trying.  There is no better example of this than how you move and view the surrounding environment while on the run.</span><P>
<span class=body>The first thing you should do after starting up is to zoom out on your "Multi Monitor" view (the top monitor that I sometimes refer to as the "Radar Screen").  This will give you a better lay of the land, and you'll be able spot potential enemies which in the default setting you wouldn't see until too late.  In the case where there are several enemies lying in wait, this zoomed out view will give you a little more time to either prepare for the inevitable confrontation, or try to avoid it<span class=date> (like a sissy.  -ed)</span>.</span><P>
<span class=body>The "Sub Monitor" (the bottom monitor) should be set to front view, especially in the early missions.  In my humble Noob opinion (IMHNO), this helps you get used to the concept and practice of using your sight change to look around through the "Main Monitor," while driving by checking the Sub Monitor.  In tight spaces and around corners when you are scanning for enemies, using the Sub Monitor will keep you from running into stuff, or worse, falling into deep water.</span><P>
<span class=body>I have read that some experienced VT pilots use lock on view, and I can understand how an experienced pilot can do this, especially in some of the outdoor missions where there is room to roam.  But for now be patient, using "Lock On View" is something us Noobs can aspire to.</span><P>
<span class=body>Also, get used to sweeping your "Targeting Reticule" across your field of vision - in addition to using the "Sight Change" - while moving, even when you don't think there are enemies in the immediate vicinity.  This serves two purposes, as you will be comfortable moving while looking around and it will prepare you for the inevitable encounter with the enemy VTs that don't show up on your radar screen, but are revealed by the targeting system.  If you're accustomed to using your "Targeting Reticule" in this manner you won't be totally surprised - and killed - when a Jarlaccs or Regal Dress pops up in front of you.</span><P>
<span class=body>Another display tip is to use the "Line Color Change" button regularly to choose the color on your "Main Monitor" display that provides you with the best contrast to the background.  This is especially important for viewing the main and sub-weapons "Targeting Arrows" that show up on either side of the "Main Targeting Reticule."  If you cannot clearly see these "Targeting Arrows" you cannot be sure that you are in effective range to use your chosen weapon.  As a result you can waste ammunition and make yourself more vulnerable to attack; both are bad things.</span><P>
<span class=body>About movement, let's keep it simple and say that the best thing that you can do is circle around your target while using your "Sight Change" and "Weapon Targeting Reticule" to stay on your enemy.  Gear down and don't be afraid to use your side step while circling.</span><P>
<span class=body>If you are into charging headlong at your opponent make sure that you keep your eye on the "Multi-Monitor" and watch for the lines heading towards you.  This is enemy - or enemies - fire, which you should avoid.  If you are at long range you can avoid incoming fire by slightly altering your heading by using your rotation lever.  Sometimes your enemy will shoot at you even though you are not in range ... know your enemy and the range of their weapons and you will have a huge advantage, especially in some of the earlier levels.  They can't hurt you if they fire from beyond the effective range of their weapons.</span><P>
<span class=body>At closer quarters you have the added benefit of seeing shots heading towards you via the "Main Monitor," and can gently hit the "Slide Step Pedal" to gracefully dodge the bullet.  Using a light touch on the "SSP" will conserve energy and will allow you to efficiently and deftly dodge several times.  If you slam on the "SSP" you will move farther than you need to and you'll heat up quicker, limiting how many times you can slide step. </span><P>
<span class=body>Have you had enough yet?  Well I have, so I'll save some goodies for next time.  Practice, practice, practice and we'll see you online!</span><p>
<span class=date>-Daredevil</span><P>
<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>