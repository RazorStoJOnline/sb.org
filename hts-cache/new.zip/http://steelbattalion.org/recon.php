<html><head><title>Steel Battalion :: Org  \\ Media</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420><img src='headerRecon.gif' height=34 width=348 alt='Recon___________'>
<P>
<img src=media.jpg>
<P>
<span class=header>Screenshots</span><br>
<span class=body>From :: </span><a href=screenshotsSB.php><span class=link>Steel Battalion</span></a><span class=date> (2)</span><br>
<span class=body>From :: </span><a href=screenshotsLOC.php><span class=link>Line Of Contact</span></a><span class=date> (33)</span><br>
<P>
<span class=header>Movies</span><br>
<span class=body>From :: </span><a href=moviesSB.php><span class=link>Steel Battalion</span></a><span class=date> (3)</span><br>
<span class=body>From :: </span><a href=moviesLOC.php><span class=link>Line Of Contact</span></a><span class=date> (4)</span><br>
<P>
<P>
<span class=header>Desktops</span><br>
<a href=desktops1600.php><span class=link>1600 x 1200</span></a><span class=date> (15)</span><br>
<a href=desktops1280.php><span class=link>1280 x 1024</span></a><span class=date> (15)</span><br>
<a href=desktops1024.php><span class=link>1024 x 768</span></a><span class=date> (15)</span><br>
<a href=desktops800.php><span class=link>800 x 600</span></a><span class=date> (15)</span><br>
<P>
<span class=header>Setups</span><br>
<a href=setups.php><span class=link>Community Setups</span></a><span class=date> (13)</span><br>
<a href=consumer.php><span class=link>Consumer Cabinets / Computing Environments</span></a><span class=date> (7)</span><br>
<P>
<span class=header>Misc.</span><br>
<a href=toys.php><span class=link>Toys</span></a><span class=date> (6)</span><br>
<a href=doodles.php><span class=link>Doodles by Yours Truly</span></a><span class=date> (10)</span><br>
<a href=drawings.php><span class=link>Concept Drawings</span></a><span class=date> (26)</span><br>
<a href=avatarSigs.php><span class=link>Avatars and Sigs</span></a><span class=date> (23)</span><br>
<a href=product.php><span class=link>Product Shots and Box Art</span></a><span class=date> (8)</span><br>
<a href=banners.php><span class=link>Banners</span></a><span class=date> (6)</span><br>
<P>
<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>
