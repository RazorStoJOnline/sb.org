<html><head><title>Steel Battalion :: Org \\ Why Should I Buy It?</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420><img src='headerRecruits.gif' height=34 width=348 alt='Recruits___________'>
<P>
<span class=header>Don't have Steel Battalion?</span>
<P>
<a href='http://www.capcom.com/SB/SB_order.html'><span class=link>Want it</span></a><span class=link>?</span>
<P>
<span class=body>This is a FAQ for the folks who don't have the game, and would like to know more about it.  I wrote it to dispell a lot of the misinformation that's going around ruining everybody's idea of what this wonderful game is really about.</span>
<P align=left>
<img src=greyPixel.gif height=1 width=100% alt=_>
<P>
<span class=header>I'd want to play the game, but it's like 500 bucks.  What's up with that?</span>
<P>
<span class=body>The release price of the game was <i>only</i> 200 dollars.  There's both a lot of confusion about this, and a lot of complaining about it; but the actual release price was 200 bucks.  That's basically 50 for the game, and 150 for the controller.  If you ask me, 150 dollars for a controller of this size and quality is better than decent.  I've seen steering wheels / arcade sticks / flight sticks for over a hundred dollars; why be surprised at a 150 dollar item that includes the complexities of this controller?!  It has <i>BLINKY LIGHTS!!</i><P></span>
<!--<span class=body>Of course, now the game is sold out in the US, and you can basically either only get it on ebay, or used for ridiculous amounts of money.  Just wait till LOC comes out.</span>
<P>-->
<span class=header>Can I play the game without that freaky controller?</span>
<P>
<span class=body>No.  You can't.  Neither can your friend who claims they can.  They are lying.</span>
<P>
<span class=header>What's the story with losing your game saves?</span>
<P>
<span class=body>Yes, it's true -- if you get killed and don't hit the "eject button" (the button with the transparent plastic protective cover over it) in time, you're screwed.  You die, and you lose your game save.  This sucks, and adds an element of realism and intensity to the game, that though awful, kinda rocks in my opinion 'cause you really freak out.  And let's face it -- the more you play these levels the better, so starting over ain't so bad.</span>
<P>
<img src=cutterBoom.jpg>
<P>
<span class=header>Where's the tape player?</span>
<P>
<span class=body>When defining the armaments of your mech, you can activate the "boom box" and listen to some funky, creepy lo-fi music while you play.  LoC supports Custom Soundtracks, and that's freakin' rad!</span>
<P>
<span class=header>Why aren't there any seagulls?</span>
<P>
<span class=body>Shut up.</span>
<P>
<span class=header>Why isn't my mech moving very fast?</span>
<P>
<span class=body>Mechs by their nature move quite slowly.  Though they lumber around step by step, the action can get REAL fast because of the nature of the camera and crosshairs. These two things can move incredibly fast, and completely independantly.  This makes for some seriously intense combat potential.  Looking one way, firing in another, and walking in another.  Pretty sweet, eh?</span>
<P>
<span class=header>The "strafe" pedal shouldn't be called a "strafe" pedal.</span>
<P>
<span class=body>Please form your questions in the form of a question.  But yes, you're right.  The strafe pedal doesn't modify your movement the same way a strafe modifier does on a keyboard -- it makes you quickly jump forward, left, right, or backwards depending on the position of the gearshift, and the direction the left joystick is pushed during the pedal depression.  If the gearshift is in N, 1, 2, 3, 4, or 5 you jump forward.  If it's in R, you'll jump backwards.  If you move the left joystick left or right while depressing the strafe pedal, you'll jump left or right.  You can also do diagonal movements with combinations of gas / strafe directions.</span>
<P>
<span class=header>When does my pilot need to eat?</span>
<P>
<span class=body>This is a sim, but not that much of a sim.</span>
<P>
<span class=header>Why's the screen all GRITTY loooking?</span>
<P>
<span class=body>Imagine this: you're sitting inside a completely enclosed metal cockpit inside the mech.  There is no windshield or glass or anything -- you look at "tv screens" inside the cockpit to see what's going on outside your mech.  There are cameras placed on the outside of the mechs which feed their signal to the interior screens which you look at.  So the quality of the image you look at is a sort of ... video resolution, and when it gets jarred (from a fall or when you're going over rough terrain or whatever)it distorts, and when it gets dirty it needs cleaning, etc.  I think it's a pretty sweet effect, and adds another level of realism to the game.</span>
<P>
<span class=header>How can I take on more than 1 mech at once?</span>
<P>
<span class=body>All you need is to keep moving, use the radar to keep an eye on incoming shells, and utilize all the tools the mech gives you.  Chaffs are handy, strafing is handy, and the fact that you can look one way, move another way, and fire your weapons another way comes in handy too.  And don't panic. :)</span>
<P>
<span class=header>Do I need a third hand to control this biyatch?</span>
<P>
<span class=body>No, but it certainly would help.</span>
<P>
<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>