<html><head><title>Steel Battalion :: Org  \\ Media</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420><img src='headerRecon.gif' height=34 width=348 alt='Recon___________'>
<P>
<span class=header>Personal Setups of People in our Community</span><br>
<a href=recon.php><span class=link>back to media</span></a>
<P>
<span class=body>If you want your setup to be included please <a href=mailto:info@steelbattalion.org><span class=link>email me</span></a> your pic(s) and a couple sentences about your setup.</span>
<P>
<span class=header>12 - Dag Sabot</span><span class=date> :: 08.16.04</span><br><span class=body>The chair is your standard Ikea brand crap-chair. The TV is a 30" Sony HD.  Here is a semi interesting tidbit: The controller is taped down to a dagger-board off a sabot (sailboat) hence the inspiration for my pilot name: Dag-Sabot (or Dog Sabot in campaign mode).</span><br><a href=media/setups/setup12.jpg><img height=121 width=420 src=media/setups/thumb12.jpg border=0></a><br><P><span class=header>11 - DWraith</span><span class=date> :: 07.10.04</span><br><span class=body>I had the chair (IKEA) $0.00 and all I needed to buy for the cockpit was $48.00 worth of wood paint. Then, with a little imagination, I came up with the bracket to attach my controller to the chair. I don't know If you can see it but I have curved molding around the edge of my lower bracket to lock my controller into place. Also, my controller/bracket combination is a "quick lift to remove or adjust setup". It is not fastened to my chair, rather fitted to it. I also made the bracket tilted up 1.5 inches so that my elbows could rest on the arms of my chair and not break the line of my wrist. Less holding up my arms = less fatigue.</span><br><a href=media/setups/setup11.jpg><img height=121 width=420 src=media/setups/thumb11.jpg border=0></a><br><P><span class=header>10 - Cloud45</span><span class=date> :: 04.14.04</span><br><span class=body>Its a relatively cramped room down stairs, i just call it "The computer room" i have the Controller on my lap :) Sound station (next to the tv) which is dolby 5.1 surround sound.</span><br><a href=media/setups/setup10.jpg><img height=121 width=420 src=media/setups/thumb10.jpg border=0></a><br><P><span class=header>9 - Getz2oo3</span><span class=date> :: 04.03.04</span><br><span class=body>Setup is a computer chair with two planks of wood bolted to each side and the controller rests snug upon them, the chair reclines backwards a good 35-40 degrees and offers excellent comfort. 27" Television with a Bose 3.1 Sound System running off a Pioneer VSX-455 Receiver, delivering awesome sound.</span><br><a href=media/setups/setup9.jpg><img height=121 width=420 src=media/setups/thumb9.jpg border=0></a><br><P><span class=header>8 - Damien</span><span class=date> :: 03.18.04</span><br><span class=body>100" screen. HDTV Front projector. 700watt Dolby Digital Ex 5.1 surround sound.</span><br><a href=media/setups/setup8.jpg><img height=121 width=420 src=media/setups/thumb8.jpg border=0></a><br><P><span class=header>7 - Asphyxiate</span><span class=date> :: 03.04.04</span><br><span class=body>Both the television and the cat flown straight in from Hell.</span><br><a href=media/setups/setup7.jpg><img height=121 width=420 src=media/setups/thumb7.jpg border=0></a><br><P><span class=header>6 - Jojo Pumpkin</span><span class=date> :: 03.04.04</span><br><span class=body>Keyboard Stand, Particle Board, Comfy Chair, and a very confused girlfriend.</span><br><a href=media/setups/setup6.jpg><img height=121 width=420 src=media/setups/thumb6.jpg border=0></a><br><P><span class=header>5 - PostalGoat</span><span class=date> :: 02.26.04</span><br><span class=body>51" HDTV, Dolby 5.1 Surround.</span><br><a href=media/setups/setup5.jpg><img height=121 width=420 src=media/setups/thumb5.jpg border=0></a><br><P><span class=header>4 - Pig Benis</span><span class=date> :: 02.12.04</span><br><span class=body>This is actually Pig's kitchen counter.  He uses the printer as a cutting board, and the monitor is his microwave.</span><br><a href=media/setups/setup4.jpg><img height=121 width=420 src=media/setups/thumb4.jpg border=0></a><br><P><span class=header>3 - Boxcar</span><span class=date> :: 02.10.04</span><br><span class=body>Two Long Boards Ductaped together, suspended on Two TV-Trays, and clamped down by four wood clamps.  Nice and sturdy.</span><br><a href=media/setups/setup3.jpg><img height=121 width=420 src=media/setups/thumb3.jpg border=0></a><br><P><span class=header>2 - The Lorax</span><span class=date> :: 02.08.04</span><br><span class=body>The lovely living room.  The neighbors will hate the subwoofer when you play this game.  You'll love it.</span><br><a href=media/setups/setup2.jpg><img height=121 width=420 src=media/setups/thumb2.jpg border=0></a><br><P><span class=header>1 - My Wife 2</span><span class=date> :: 02.08.04</span><br><span class=body>This is where I like to play.  7.5 foot HDTV front projector, 5.1 silly surround sound system with reference Klipsch and Axiom audio / Denon hardware.</span><br><a href=media/setups/setup1.jpg><img height=121 width=420 src=media/setups/thumb1.jpg border=0></a><br><P><span class=header>0 - My Wife 1</span><span class=date> :: 02.08.04</span><br><span class=body>This is where I play when I'm recording video or taking screenshots or if just need to get a quick game in while I'm supposed to be getting work done.  It's got a cute little 5.1 setup.</span><br><a href=media/setups/setup0.jpg><img height=121 width=420 src=media/setups/thumb0.jpg border=0></a><br><P><P>
<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>