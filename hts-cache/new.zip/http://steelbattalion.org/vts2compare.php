<html><head><title>Steel Battalion :: Org  \\ Compare VTs</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420><img src='headerVT.gif' height=34 width=348 alt='Recon___________'><P>
<a href=vts2.php><img src=weaponButtonTanksGrey.gif border=0></a><a href=weaponsMain2.php><img src=weaponButtonMainGrey.gif border=0></a><a href=weaponsSub2.php><img src=weaponButtonSubGrey.gif border=0></a><P>
<span class=header>Compare your favorite VTs! <span class=date>:: funtimes</span></span><br><img src=greyPixel.gif width=100% height=1><br><span class=body>Select the VTs you want to compare and press the "compare!" button.  If you only want to compare 2 or 3 VTs, do so using the 1st and 2nd dropdowns etc., otherwise it gets screwed up.  I'd fix it, but I'm lazy.</span><P>
<table align=center><tr><td align=center width=400><form action="vts2compare.php" method="get" name="myform"><select name="compare0"><option value="">1 : Select Something!</option><option value=Vitzh>1 : Vitzh</option><option value=M-Vitzh>1 : M-Vitzh</option><option value=Vortex>1 : Vortex</option><option value=Scare_Face>1 : Scare_Face</option><option value=Scare_Face_A1>1 : Scare_Face_A1</option><option value=Scare_Face_II>1 : Scare_Face_II</option><option value=Maelstrom>1 : Maelstrom</option><option value=Behemoth>1 : Behemoth</option><option value=Garpike>1 : Garpike</option><option value=Regal_Dress_A>1 : Regal_Dress_A</option><option value=Regal_Dress_N>1 : Regal_Dress_N</option><option value=Juggernaut>1 : Juggernaut</option><option value=Decider>1 : Decider</option><option value=Falchion>1 : Falchion</option><option value=Decider_Volcanic>1 : Decider_Volcanic</option><option value=Blade>1 : Blade</option><option value=Prominence_M1>1 : Prominence_M1</option><option value=Rapier>1 : Rapier</option><option value=Prominence_M2>1 : Prominence_M2</option><option value=Prominence_M3>1 : Prominence_M3</option><option value=Quasar>1 : Quasar</option><option value=Colt>1 : Colt</option><option value=Colt_Executive>1 : Colt_Executive</option><option value=Yellow_Jacket>1 : Yellow_Jacket</option><option value=Sheep_Dog>1 : Sheep_Dog</option><option value=Siegeszug>1 : Siegeszug</option><option value=Earthshaker>1 : Earthshaker</option><option value=Jaralaccs_C>1 : Jaralaccs_C</option><option value=Jaralaccs_N>1 : Jaralaccs_N</option><option value=Jaralaccs_NS-R>1 : Jaralaccs_NS-R</option><option value=Jaralaccs_Macabre>1 : Jaralaccs_Macabre</option></select><select name="compare1"><option value="">2 : Select Something!</option><option value=Vitzh>2 : Vitzh</option><option value=M-Vitzh>2 : M-Vitzh</option><option value=Vortex>2 : Vortex</option><option value=Scare_Face>2 : Scare_Face</option><option value=Scare_Face_A1>2 : Scare_Face_A1</option><option value=Scare_Face_II>2 : Scare_Face_II</option><option value=Maelstrom>2 : Maelstrom</option><option value=Behemoth>2 : Behemoth</option><option value=Garpike>2 : Garpike</option><option value=Regal_Dress_A>2 : Regal_Dress_A</option><option value=Regal_Dress_N>2 : Regal_Dress_N</option><option value=Juggernaut>2 : Juggernaut</option><option value=Decider>2 : Decider</option><option value=Falchion>2 : Falchion</option><option value=Decider_Volcanic>2 : Decider_Volcanic</option><option value=Blade>2 : Blade</option><option value=Prominence_M1>2 : Prominence_M1</option><option value=Rapier>2 : Rapier</option><option value=Prominence_M2>2 : Prominence_M2</option><option value=Prominence_M3>2 : Prominence_M3</option><option value=Quasar>2 : Quasar</option><option value=Colt>2 : Colt</option><option value=Colt_Executive>2 : Colt_Executive</option><option value=Yellow_Jacket>2 : Yellow_Jacket</option><option value=Sheep_Dog>2 : Sheep_Dog</option><option value=Siegeszug>2 : Siegeszug</option><option value=Earthshaker>2 : Earthshaker</option><option value=Jaralaccs_C>2 : Jaralaccs_C</option><option value=Jaralaccs_N>2 : Jaralaccs_N</option><option value=Jaralaccs_NS-R>2 : Jaralaccs_NS-R</option><option value=Jaralaccs_Macabre>2 : Jaralaccs_Macabre</option></select><select name="compare2"><option value="">3 : Select Something!</option><option value=Vitzh>3 : Vitzh</option><option value=M-Vitzh>3 : M-Vitzh</option><option value=Vortex>3 : Vortex</option><option value=Scare_Face>3 : Scare_Face</option><option value=Scare_Face_A1>3 : Scare_Face_A1</option><option value=Scare_Face_II>3 : Scare_Face_II</option><option value=Maelstrom>3 : Maelstrom</option><option value=Behemoth>3 : Behemoth</option><option value=Garpike>3 : Garpike</option><option value=Regal_Dress_A>3 : Regal_Dress_A</option><option value=Regal_Dress_N>3 : Regal_Dress_N</option><option value=Juggernaut>3 : Juggernaut</option><option value=Decider>3 : Decider</option><option value=Falchion>3 : Falchion</option><option value=Decider_Volcanic>3 : Decider_Volcanic</option><option value=Blade>3 : Blade</option><option value=Prominence_M1>3 : Prominence_M1</option><option value=Rapier>3 : Rapier</option><option value=Prominence_M2>3 : Prominence_M2</option><option value=Prominence_M3>3 : Prominence_M3</option><option value=Quasar>3 : Quasar</option><option value=Colt>3 : Colt</option><option value=Colt_Executive>3 : Colt_Executive</option><option value=Yellow_Jacket>3 : Yellow_Jacket</option><option value=Sheep_Dog>3 : Sheep_Dog</option><option value=Siegeszug>3 : Siegeszug</option><option value=Earthshaker>3 : Earthshaker</option><option value=Jaralaccs_C>3 : Jaralaccs_C</option><option value=Jaralaccs_N>3 : Jaralaccs_N</option><option value=Jaralaccs_NS-R>3 : Jaralaccs_NS-R</option><option value=Jaralaccs_Macabre>3 : Jaralaccs_Macabre</option></select><select name="compare3"><option value="">4 : Select Something!</option><option value=Vitzh>4 : Vitzh</option><option value=M-Vitzh>4 : M-Vitzh</option><option value=Vortex>4 : Vortex</option><option value=Scare_Face>4 : Scare_Face</option><option value=Scare_Face_A1>4 : Scare_Face_A1</option><option value=Scare_Face_II>4 : Scare_Face_II</option><option value=Maelstrom>4 : Maelstrom</option><option value=Behemoth>4 : Behemoth</option><option value=Garpike>4 : Garpike</option><option value=Regal_Dress_A>4 : Regal_Dress_A</option><option value=Regal_Dress_N>4 : Regal_Dress_N</option><option value=Juggernaut>4 : Juggernaut</option><option value=Decider>4 : Decider</option><option value=Falchion>4 : Falchion</option><option value=Decider_Volcanic>4 : Decider_Volcanic</option><option value=Blade>4 : Blade</option><option value=Prominence_M1>4 : Prominence_M1</option><option value=Rapier>4 : Rapier</option><option value=Prominence_M2>4 : Prominence_M2</option><option value=Prominence_M3>4 : Prominence_M3</option><option value=Quasar>4 : Quasar</option><option value=Colt>4 : Colt</option><option value=Colt_Executive>4 : Colt_Executive</option><option value=Yellow_Jacket>4 : Yellow_Jacket</option><option value=Sheep_Dog>4 : Sheep_Dog</option><option value=Siegeszug>4 : Siegeszug</option><option value=Earthshaker>4 : Earthshaker</option><option value=Jaralaccs_C>4 : Jaralaccs_C</option><option value=Jaralaccs_N>4 : Jaralaccs_N</option><option value=Jaralaccs_NS-R>4 : Jaralaccs_NS-R</option><option value=Jaralaccs_Macabre>4 : Jaralaccs_Macabre</option></select><br><input type="submit" value="compare!" align="middle"></form></td></tr></table><P>
<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>