<html><head><title>Steel Battalion :: Org \\ Online Warfare</title>

<LINK REL=stylesheet HREF="sbdotorg.css" TYPE="text/css">
<script language="Javascript">

function rollOver(imgNum,imgSrc) {
	document.images[imgNum].src = imgSrc;
}

</script></head>
<body bgcolor=white marginheight=0 marginwidth=0 topmargin=0 leftmargin=0 link=B2991F vlink=B2991F alink=222222>
<table width=750 border=0 cellpadding=0 spacing=0 cellspacing=0>
<tr><td align=left colspan=3><a name=top><img src=top.gif border=0 height=128 width=617></td></tr>
<tr><td align=left width=144  valign=top><img src=nav01.gif height=30 border=0><br>
<a href='index.php' onMouseOver="rollOver('home','navHomeOver.gif');" onMouseOut="rollOver('home','navHome.gif');"
><img src=navHome.gif height=19 border=0 name=home></a><br>
<a href='recruits.php' onMouseOver="rollOver('why','navWhybuyOver.gif');" onMouseOut="rollOver('why','navWhybuy.gif');"
><img src=navWhybuy.gif height=23 border=0 name=why></a><br>
<a href='manual.php' onMouseOver="rollOver('manual','navManualOver.gif');" onMouseOut="rollOver('manual','navManual.gif');"
><img src=navManual.gif height=23 border=0 name=manual></a><br>
<a href='fieldNotes.php' onMouseOver="rollOver('walkthrough','navWalkthroughOver.gif');" onMouseOut="rollOver('walkthrough','navWalkthrough.gif');"
><img src=navWalkthrough.gif height=23 border=0 name=walkthrough></a><br>
<a href='controller.php' onMouseOver="rollOver('controller','navControllerOver.gif');" onMouseOut="rollOver('controller','navController.gif');"
><img src=navController.gif height=23 border=0 name=controller></a><br>
<a href='vts2.php' onMouseOver="rollOver('vts','navVTover.gif');" onMouseOut="rollOver('vts','navVT.gif');"
><img src=navVT.gif height=23 border=0 name=vts></a><br>
<a href='recon.php' onMouseOver="rollOver('media','navMediaOver.gif');" onMouseOut="rollOver('media','navMedia.gif');"
><img src=navMedia.gif height=23 border=0 name=media></a><br>
<a href='warfare.php' onMouseOver="rollOver('online','navOnlineOver.gif');" onMouseOut="rollOver('online','navOnline.gif');"
><img src=navOnline.gif height=23 border=0 name=online></a><br>
<a href='http://lineofcontact.net/forums/index.php' onMouseOver="rollOver('forum','navForumOver.gif');" onMouseOut="rollOver('forum','navForum.gif');"
><img src=navForum.gif height=23 border=0 name=forum></a><br>
<a href='' onMouseOver="rollOver('nuffin','nav02b.gif');" onMouseOut="rollOver('nuffin','nav02.gif');"
><img src=nav02.gif height=202 border=0 name=nuffin></a><br>
</td><td align=left valign=top width=420><img src='headerWarfare.gif' height=34 width=348 alt='Warfare___________'>
<P>
<span class=body>Steel Battalion: Line Of Contact (LOC) has been unleashed.  It is an XBox Live enabled squad based version of the game we know and love.</span><P>
<img src=locMain.jpg><P>
<span class=header>Table of Contents:</span><br><img src=greyPixel.gif width=100% height=1><P>
<a href=http://www.lineofcontact.net><span class=link>LOC dot Net</span></a><span class=date> An incredible info-filled site about Line of Contact.</span><br>
<a href=locBasics.php><span class=link>LoC Basics</span></a><span class=date> General info about purchasing LoC and features</span><br>
<a href=locGameModes.php><span class=link>Game Modes</span></a><span class=date> Campaign / Free Mission and how they work</span><br>
<a href=locFactions.php><span class=link>Factions</span></a><span class=date> What this means to YOU</span><br>
<a href=locMaps.php><span class=link>Maps</span></a><span class=date> Where you'll be laying waste to your stupid friends</span><br>
<a href=locCustomization.php><span class=link>Customization</span></a><span class=date> How to tweak your VT to hell</span><br>
<a href=commTutorial.php><span class=link>Communication Tutorial</span></a><span class=date> Because you might need it</span><br>
<a href=locClans.php><span class=link>Clans</span></a><span class=date> Links to Clans with LoC affiliations</span><p>
<a href=links.php><span class=link>Links</span></a><span class=date> This is how the internet works. Share!</span><br>
<P>
<table width=100% height=80><tr><td align=center valign=bottom>
<img src=endBit.gif>
</td></tr></table>
</td><td>&nbsp;</td></tr></table>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1627682-10");
pageTracker._trackPageview();
} catch(err) {}</script>
</body>
</html>